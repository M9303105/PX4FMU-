  t0 = _symans_32_297;
